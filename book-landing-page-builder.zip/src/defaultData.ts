import { LandingPageConfig } from "./types";

export const DEFAULT_CONFIG: LandingPageConfig = {
  headerTitle: "CÂU LẠC BỘ SÁCH TINH HOA vN",
  headerNotice: "⚡ Miễn Phí Vận Chuyển Toàn Quốc - Kiểm Tra Hàng Trước Khi Thanh Toán",
  bookTitle: "TƯ DUY NGƯỢC - ĐỘT PHÁ VẬN MỆNH",
  bookSubtitle: "Cuốn sách thay đổi tư duy của hàng triệu người trẻ, phá vỡ mọi lối mòn lối tư duy cũ kỹ và kiến tạo cuộc sống thịnh vượng bền vững.",
  bookCoverUrl: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=600",
  ratingScore: "4.9",
  ratingCount: "14,850",
  countdownMinutes: 25,
  discountPercentage: 50,
  
  problemTitle: "BẠN CÓ ĐANG GẶP PHẢI NHỮNG KHÓ KHĂN NÀY?",
  problems: [
    "Luôn cảm thấy bế tắc, trì hoãn và không tìm ra hướng đi đột phá cho bản thân.",
    "Làm việc cật lực nhưng thu nhập vẫn lẹt đẹt, không quản lý được dòng tiền cá nhân.",
    "Bị cuốn theo suy nghĩ số đông, thường xuyên rơi vào lo âu, stress và mất định hướng.",
    "Giao tiếp thiếu tự tin, khó thuyết phục người khác và thiết lập các mối quan hệ chất lượng."
  ],
  
  solutionTitle: "CUỐN SÁCH NÀY SẼ LÀ CHIẾC CHÌA KHÓA MỞ RA CÁNH CỬA MỚI",
  solutions: [
    {
      title: "Phá vỡ tư duy lối mòn",
      desc: "Cách suy nghĩ độc bản, bóc tách vấn đề theo phương pháp 'tư duy ngược' giúp bạn nhìn thấu cơ hội khi người khác chỉ thấy thách thức."
    },
    {
      title: "Làm chủ tài chính cá nhân",
      desc: "Công thức tối ưu hóa chi tiêu, nhân bản dòng tiền và định vị tư thế làm giàu từ các bậc thầy tài chính hàng đầu."
    },
    {
      title: "Rèn luyện thần thái tự tin",
      desc: "Giải phóng nỗi sợ hãi, thiết lập tư duy tích cực bền vững và làm chủ mọi hoàn cảnh giao tiếp đỉnh cao."
    }
  ],
  
  benefitsTitle: "BẠN SẼ NHẬN ĐƯỢC GÌ SAU KHI ĐỌC CUỐN SÁCH?",
  benefits: [
    "Sở hữu bản đồ tư duy ngược đột phá để tự giải quyết mọi bài toán cuộc đời.",
    "Tăng 200% hiệu suất làm việc nhờ loại bỏ thói quen trì hoãn tiêu cực.",
    "Xây dựng kế hoạch tài chính vững vàng chỉ trong 30 ngày áp dụng thực tế.",
    "Trở thành phiên bản tự tin nhất, thu hút cơ hội thăng tiến và hạnh phúc.",
    "Tặng kèm: Bản PDF Nhật ký thực hành Tư Duy Ngược & Phiếu ưu đãi 20% khóa học chuyên sâu."
  ],
  
  packagesTitle: "CHƯƠNG TRÌNH ƯU ĐÃI ĐẶC BIỆT (CHỈ HÔM NAY)",
  packages: [
    {
      id: "pkg-1",
      name: "Gói Trải Nghiệm (Mua 1 Cuốn)",
      originalPrice: 398000,
      salePrice: 199000,
      description: "Tiết kiệm 50% + Tặng Bookmark nghệ thuật. Phí ship toàn quốc 25k."
    },
    {
      id: "pkg-2",
      name: "Combo Đột Phá (Mua 2 Cuốn) - BEST SELLER ✦",
      originalPrice: 796000,
      salePrice: 349000,
      badge: "KHUYÊN DÙNG",
      description: "Miễn Phí Ship Toàn Quốc + Tặng Sách Nói Bản Quyền + Bản PDF Nhật Ký Thực Hành."
    },
    {
      id: "pkg-3",
      name: "Combo Đồng Đội (Mua 3 Cuốn)",
      originalPrice: 1194000,
      salePrice: 489000,
      badge: "TIẾT KIỆM NHẤT",
      description: "Miễn Phí Ship Toàn Quốc + Tặng Toàn Bộ Quà Tặng Đột Phá + Thẻ Thành Viên VIP CLB."
    }
  ],
  
  testimonialsTitle: "HƠN 14.800+ ĐỘC GIẢ ĐÃ THAY ĐỔI CUỘC ĐỜI THÀNH CÔNG",
  testimonials: [
    {
      id: "rev-1",
      author: "Nguyễn Minh Thư",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150",
      rating: 5,
      date: "Vừa xong",
      content: "Cuốn sách thực sự là một cú tát tỉnh thức đối với mình. Lối hành văn cực kỳ gần gũi, đụng chạm đến những vết thương giấu kín của người trẻ và vẽ đường đi cụ thể. Mình đã hết thói quen trì hoãn!",
      verified: true,
      replies: [
        {
          author: "Nhà sách Tinh Hoa",
          content: "Cảm ơn Minh Thư rất nhiều! Chúc bạn gặt hái được nhiều thành công hơn nữa trên hành trình Tư duy ngược nhé! 💖"
        }
      ]
    },
    {
      id: "rev-2",
      author: "Trần Hoàng Nam",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150",
      rating: 5,
      date: "12 phút trước",
      content: "Chất lượng sách tuyệt vời, bìa cứng sang chảnh lắm nha mọi người. Đóng gói rất kỹ, giao hàng sau 2 ngày đã nhận được rồi. Rất ưng ý với combo 2 cuốn siêu tiết kiệm.",
      verified: true
    },
    {
      id: "rev-3",
      author: "Lê Thị Lan Anh",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150",
      rating: 5,
      date: "30 phút trước",
      content: "Lúc đầu mua định đọc thử xem sao thôi, mà càng đọc càng cuốn không dứt ra nổi. Từng trang sách như có lực hút ấy. Rất thích phương pháp quản lý tài chính trong chương 4, rất thực tế.",
      verified: true,
      replies: [
        {
          author: "Nhà sách Tinh Hoa",
          content: "Dạ cảm ơn chị Lan Anh ạ, chương tài chính được cố vấn bởi các chuyên gia nên áp dụng rất nhanh hiệu quả đó ạ!"
        }
      ]
    }
  ],
  
  googleSheetUrl: "https://script.google.com/macros/s/AKfycbz_XXXXXXXX_YOUR_DEPLOYED_WEBAPP_URL/exec",
  
  companyName: "CÔNG TY CỔ PHẦN PHÁT TRIỂN VĂN HÓA SÁCH TINH HOA VIỆT NAM",
  companyAddress: "Tòa nhà Landmark 81, Landmark Riverside, Phường 22, Quận Bình Thạnh, Tp. Hồ Chí Minh",
  companyContact: "Hotline: 1900 8888 | Email: hotro@sachtinhhoa.vn | MST: 031567499"
};

export interface BookPackage {
  id: string;
  name: string;
  originalPrice: number;
  salePrice: number;
  badge?: string;
  description: string;
}

export interface Review {
  id: string;
  author: string;
  avatar: string;
  rating: number;
  date: string;
  content: string;
  verified: boolean;
  replies?: Array<{ author: string; content: string }>;
}

export interface LandingPageConfig {
  headerTitle: string;
  headerNotice: string;
  bookTitle: string;
  bookSubtitle: string;
  bookCoverUrl: string;
  ratingScore: string;
  ratingCount: string;
  countdownMinutes: number;
  discountPercentage: number;
  
  // Pain points & Solutions
  problemTitle: string;
  problems: string[];
  solutionTitle: string;
  solutions: { title: string; desc: string }[];
  
  // Contents & Benefits
  benefitsTitle: string;
  benefits: string[];
  
  // Packages
  packagesTitle: string;
  packages: BookPackage[];
  
  // Testimonials
  testimonialsTitle: string;
  testimonials: Review[];
  
  // Google Sheets / Webhook Sync
  googleSheetUrl: string;
  
  // Company details
  companyName: string;
  companyAddress: string;
  companyContact: string;
}

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  selectedPackageId: string;
  selectedPackageName: string;
  totalPrice: number;
  note?: string;
  createdAt: string;
}

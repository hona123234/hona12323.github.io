import React, { useState, useEffect } from "react";
import { 
  BookOpen, 
  FileCode, 
  ClipboardList, 
  HelpCircle, 
  Smartphone, 
  Copy, 
  Check, 
  Download, 
  Trash2, 
  Plus, 
  Trash, 
  RotateCcw,
  Sparkles,
  Link,
  Phone,
  MapPin,
  MessageSquare,
  Gift,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowRight
} from "lucide-react";
import { LandingPageConfig, Order, BookPackage } from "./types";
import { DEFAULT_CONFIG } from "./defaultData";
import { generateElementorHTML } from "./utils";

export default function App() {
  // --- STATE SYSTEM ---
  const [config, setConfig] = useState<LandingPageConfig>(() => {
    const saved = localStorage.getItem("book_lp_config");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Ensure structure matches
        return { ...DEFAULT_CONFIG, ...parsed };
      } catch (e) {
        return DEFAULT_CONFIG;
      }
    }
    return DEFAULT_CONFIG;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem("book_lp_orders");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return [];
      }
    }
    return [];
  });

  const [activeTab, setActiveTab] = useState<"edit" | "code" | "orders" | "guide">("edit");
  const [activeSubTab, setActiveSubTab] = useState<"general" | "problems" | "packages" | "testimonials">("general");
  const [isCopied, setIsCopied] = useState(false);
  const [successOrder, setSuccessOrder] = useState<Order | null>(null);
  
  // Mobile preview live interactive values
  const [selectedPackageId, setSelectedPackageId] = useState<string>("pkg-2");
  const [clientName, setClientName] = useState("");
  const [clientPhone, setClientPhone] = useState("");
  const [clientAddress, setClientAddress] = useState("");
  const [clientNote, setClientNote] = useState("");
  const [phoneError, setPhoneError] = useState(false);
  const [countdown, setCountdown] = useState({ hrs: 0, mins: config.countdownMinutes, secs: 35 });
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinResult, setSpinResult] = useState<string | null>(null);
  const [hasSpun, setHasSpun] = useState(false);
  const [wheelRotation, setWheelRotation] = useState(0);

  // Review interaction state in mobile preview
  const [userStars, setUserStars] = useState(5);
  const [userCommentName, setUserCommentName] = useState("");
  const [userCommentText, setUserCommentText] = useState("");
  const [customReviews, setCustomReviews] = useState<typeof config.testimonials>([]);

  // To check if testing webhook
  const [webhookStatus, setWebhookStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [webhookMessage, setWebhookMessage] = useState("");

  // Persist config and orders
  useEffect(() => {
    localStorage.setItem("book_lp_config", JSON.stringify(config));
  }, [config]);

  useEffect(() => {
    localStorage.setItem("book_lp_orders", JSON.stringify(orders));
  }, [orders]);

  // Countdown timer effect for preview
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev.secs > 0) {
          return { ...prev, secs: prev.secs - 1 };
        } else if (prev.mins > 0) {
          return { hrs: prev.hrs, mins: prev.mins - 1, secs: 59 };
        } else {
          // loop back countdown to maintain urgency vibe (standard sales LP practice)
          return { hrs: 0, mins: config.countdownMinutes, secs: 59 };
        }
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [config.countdownMinutes]);

  // Handle new input changes
  const handleInputChange = (field: keyof LandingPageConfig, value: any) => {
    setConfig(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Helper for sub list editing (such as problems)
  const handleListItemChange = (field: "problems" | "benefits", index: number, value: string) => {
    setConfig(prev => {
      const list = [...prev[field]];
      list[index] = value;
      return { ...prev, [field]: list };
    });
  };

  const addListItem = (field: "problems" | "benefits", placeholderValue: string) => {
    setConfig(prev => ({
      ...prev,
      [field]: [...prev[field], placeholderValue]
    }));
  };

  const removeListItem = (field: "problems" | "benefits", index: number) => {
    setConfig(prev => {
      const list = [...prev[field]];
      list.splice(index, 1);
      return { ...prev, [field]: list };
    });
  };

  // Solutions grid helper
  const handleSolutionChange = (index: number, key: "title" | "desc", value: string) => {
    setConfig(prev => {
      const list = [...prev.solutions];
      list[index] = { ...list[index], [key]: value };
      return { ...prev, solutions: list };
    });
  };

  // Package dynamic editing
  const handlePackageChange = (index: number, key: keyof BookPackage, value: any) => {
    setConfig(prev => {
      const list = [...prev.packages];
      list[index] = { ...list[index], [key]: value };
      return { ...prev, packages: list };
    });
  };

  const addPackage = () => {
    const newPkg: BookPackage = {
      id: `pkg-${Date.now()}`,
      name: "Tên gói sản phẩm mới",
      originalPrice: 299000,
      salePrice: 149000,
      description: "Mô tả nội dung khuyến mãi kèm theo của bạn..."
    };
    setConfig(prev => ({
      ...prev,
      packages: [...prev.packages, newPkg]
    }));
  };

  const removePackage = (index: number) => {
    setConfig(prev => {
      const list = [...prev.packages];
      list.splice(index, 1);
      return { ...prev, packages: list };
    });
  };

  // Testimonials custom helper
  const handleTestimonialChange = (index: number, key: string, value: any) => {
    setConfig(prev => {
      const list = [...prev.testimonials];
      list[index] = { ...list[index], [key]: value };
      return { ...prev, testimonials: list };
    });
  };

  const addTestimonial = () => {
    const newReview = {
      id: `rev-${Date.now()}`,
      author: "Họ tên độc giả mới",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150",
      rating: 5,
      date: "Vừa xong",
      content: "Nhập nhận xét hoặc feedback của độc giả tại đây. Nhận xét chân thực sẽ tăng vọt lòng tin.",
      verified: true
    };
    setConfig(prev => ({
      ...prev,
      testimonials: [...prev.testimonials, newReview]
    }));
  };

  const removeTestimonial = (index: number) => {
    setConfig(prev => {
      const list = [...prev.testimonials];
      list.splice(index, 1);
      return { ...prev, testimonials: list };
    });
  };

  // Reset to original defaults
  const handleResetDefaults = () => {
    if (window.confirm("Bạn có chắc chắn muốn khôi phục toàn bộ nội dung về mặc định của Chuyên gia UI/UX?")) {
      setConfig(DEFAULT_CONFIG);
      setCustomReviews([]);
      localStorage.removeItem("book_lp_config");
    }
  };

  // Copy HTML script to clipboard
  const handleCopyCode = () => {
    const htmlCode = generateElementorHTML(config);
    navigator.clipboard.writeText(htmlCode);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  // Download code as HTML File
  const handleDownloadCode = () => {
    const htmlCode = generateElementorHTML(config);
    const blob = new Blob([htmlCode], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `landingpage_book_${config.bookTitle.toLowerCase().replace(/\s+/g, "_")}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Simulate lucky spin wheel inside interactive mobile layout
  const handleSpinWheel = () => {
    if (hasSpun) {
      alert("Mỗi khách hàng chỉ được tham gia quay thưởng 1 lần!");
      return;
    }
    setIsSpinning(true);
    // spin by 5 turns + some angle
    const targetRot = 1800 + 45; // 45 degree is free ship sector basically
    setWheelRotation(targetRot);
    
    setTimeout(() => {
      setIsSpinning(false);
      setSpinResult("🎁 Chúc mừng! Bạn trúng mã MIỄN PHÍ VẬN CHUYỂN TOÀN QUỐC + Sách nói bản quyền!");
      setHasSpun(true);
      alert("Chúc mừng! Bạn đã trúng giải 'MIỄN PHÍ VẬN CHUYỂN TOÀN QUỐC'. Quyền lợi đã tự động áp dụng khi điền đơn hàng bên dưới!");
      // scroll to checkout container smoothly
      const element = document.getElementById("mobile-checkout-anchor");
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }, 3000);
  };

  // Order Submission simulated process inside iPhone preview
  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // validate Vietnamese phone number (starts with 0, total 10 digits)
    const phoneRegex = /^(03|05|07|08|09)\d{8}$/;
    if (!phoneRegex.test(clientPhone)) {
      setPhoneError(true);
      return;
    }
    setPhoneError(false);

    const selectedPkg = config.packages.find(p => p.id === selectedPackageId) || config.packages[0];

    const newOrder: Order = {
      id: `ord-${Date.now().toString().slice(-6)}`,
      customerName: clientName,
      customerPhone: clientPhone,
      customerAddress: clientAddress,
      selectedPackageId: selectedPkg.id,
      selectedPackageName: selectedPkg.name,
      totalPrice: selectedPkg.salePrice,
      note: clientNote,
      createdAt: new Date().toLocaleString("vi-VN")
    };

    // Store in active state
    setOrders(prev => [newOrder, ...prev]);
    setSuccessOrder(newOrder);

    // Call user specified Webhook link if any
    if (config.googleSheetUrl && config.googleSheetUrl !== "https://script.google.com/macros/s/AKfycbz_XXXXXXXX_YOUR_DEPLOYED_WEBAPP_URL/exec") {
      setWebhookStatus("sending");
      setWebhookMessage("Đang đồng bộ dữ liệu sang Google Sheet...");
      
      // POST payload (usually cors needs to be handle gracefully on gas side, standard is no-cors for direct posting)
      fetch(config.googleSheetUrl, {
        method: "POST",
        mode: "no-cors",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          fullName: newOrder.customerName,
          phoneNumber: newOrder.customerPhone,
          shippingAddress: newOrder.customerAddress,
          noteMessage: newOrder.note || "",
          packageName: newOrder.selectedPackageName,
          packageId: newOrder.selectedPackageId,
          totalPrice: newOrder.totalPrice,
          currentTime: newOrder.createdAt
        })
      })
      .then(() => {
        setWebhookStatus("success");
        setWebhookMessage("Đồng bộ Google Sheets thành công!");
      })
      .catch(err => {
        console.error("Webhook error:", err);
        setWebhookStatus("error");
        setWebhookMessage("Lỗi kết nối Webhook. Bạn đã cấp quyền Web App thành công chưa?");
      });
    }
  };

  // Trigger manual webhook test call
  const testWebhookDirect = () => {
    if (!config.googleSheetUrl || config.googleSheetUrl.includes("XXXXXXXX")) {
      alert("Vui lòng dán liên kết Google Web App thực tế của bạn trước khi kiểm tra!");
      return;
    }
    setWebhookStatus("sending");
    setWebhookMessage("Đang gửi đơn hàng thử nghiệm...");

    const testPayload = {
      fullName: "Độc Giả Thử Nghiệm",
      phoneNumber: "0900000000",
      shippingAddress: "Tòa nhà Landmark 81, Landmark Riverside, Tp. HCM",
      noteMessage: "Đơn hàng kiểm tra kết nối trực tiếp",
      packageName: "Combo Đột Phá (Mua 2 Cuốn)",
      packageId: "pkg-test",
      totalPrice: 349000,
      currentTime: new Date().toLocaleString("vi-VN")
    };

    fetch(config.googleSheetUrl, {
      method: "POST",
      mode: "no-cors",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(testPayload)
    })
    .then(() => {
      setWebhookStatus("success");
      setWebhookMessage("Gửi đơn hàng thử nghiệm thành công! Hãy kiểm tra Google Sheet.");
      alert("Đồng bộ Thử nghiệm thành công! Google Sheet của bạn sẽ nhận được một dòng mới nếu đoạn script được thiết lập chính xác.");
    })
    .catch(err => {
      setWebhookStatus("error");
      setWebhookMessage("Lỗi lỗi kết nối (CORS hoặc URL sai)");
      alert(`Đã xảy ra lỗi khi kết nối Webhook: ${err.message}`);
    });
  };

  // Close live Success Popup modal
  const handleCloseSuccessPopup = () => {
    setSuccessOrder(null);
    setClientName("");
    setClientPhone("");
    setClientAddress("");
    setClientNote("");
  };

  // Add testimonial mock comment inside mobile layout
  const handleAddPreviewReview = () => {
    if (!userCommentName.trim() || !userCommentText.trim()) {
      alert("Vui lòng điền đầy đủ tên và cảm nhận!");
      return;
    }
    const newRev = {
      id: `rev-usr-${Date.now()}`,
      author: userCommentName,
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=150",
      rating: userStars,
      date: "Vừa xong",
      content: userCommentText,
      verified: true
    };
    setCustomReviews(prev => [newRev, ...prev]);
    setUserCommentName("");
    setUserCommentText("");
    alert("Cảm ơn bạn đã gửi bình luận thử nghiệm trong Preview điện thoại!");
  };

  const deleteOrder = (id: string) => {
    setOrders(prev => prev.filter(o => o.id !== id));
  };

  const clearAllOrders = () => {
    if (window.confirm("Bạn có tin chắc muốn xóa toàn bộ danh sách đơn hàng đã thu thập?")) {
      setOrders([]);
    }
  };

  // Export current orders to CSV
  const exportAllOrdersCSV = () => {
    if (orders.length === 0) {
      alert("Hiện chưa có đơn hàng nào để xuất tệp!");
      return;
    }
    // Excel friendly BOM characters for UTF-8 Vietnamese diacritics
    let csvContent = "\ufeff";
    csvContent += "Mã Đơn,Khách Hàng,Số Điện Thoại,Địa Chỉ,Gói Sản Phẩm,Thành Tiền,Lưu Ý,Thời Gian\n";
    
    orders.forEach(o => {
      csvContent += `"${o.id}","${o.customerName}","${o.customerPhone}","${o.customerAddress.replace(/"/g, '""')}","${o.selectedPackageName}","${o.totalPrice}","${(o.note || "").replace(/"/g, '""')}","${o.createdAt}"\n`;
    });

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "danh_sach_don_hang_dat_sach.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // VND Pricing Formatter
  const formatMoney = (amount: number) => {
    return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(amount);
  };

  return (
    <div className="bg-slate-900 text-slate-100 min-h-screen flex flex-col font-sans">
      
      {/* HEADER BAR */}
      <header className="bg-slate-950 border-b border-slate-800 px-6 py-4 flex flex-col md:flex-row justify-between items-center gap-4 z-20 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-tr from-rose-500 to-orange-500 rounded-xl p-2.5 shadow-md">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-black tracking-tight text-white uppercase flex items-center gap-2">
              Book Landing Page Builder 
              <span className="bg-rose-500/15 text-rose-400 border border-rose-500/30 text-[10px] uppercase px-2 py-0.5 rounded-full font-bold">
                Mobile-Optimized
              </span>
            </h1>
            <p className="text-xs text-slate-400">Thiết kế, Xem trước thời gian thực & Xuất mã HTML/CSS sang Elementor - WordPress</p>
          </div>
        </div>

        <div className="flex justify-center items-center gap-2.5">
          <button
            onClick={handleResetDefaults}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white px-3 py-2 rounded-xl text-xs font-semibold border border-slate-700 transition"
            title="Trả về cấu hình mẫu chuyển đổi cao chuẩn ban đầu"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Khôi phục mặc định
          </button>
          
          <button
            onClick={handleDownloadCode}
            className="flex items-center gap-1.5 bg-rose-600 hover:bg-rose-500 text-white px-4 py-2 rounded-xl text-xs font-extrabold shadow-lg transition"
          >
            <Download className="w-3.5 h-3.5" />
            Tải File .HTML
          </button>
        </div>
      </header>

      {/* CORE WORKSPACE */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        
        {/* LEFT WORKSPACE PANELS */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 lg:border-r lg:border-slate-800 max-w-full lg:max-w-2xl bg-slate-900/60 scrollbar-thin">
          
          {/* TAB SWITCHERS */}
          <nav className="flex bg-slate-950 p-1.5 rounded-2xl mb-6 border border-slate-800/80 gap-1.5">
            <button
              onClick={() => setActiveTab("edit")}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all duration-200 ${
                activeTab === "edit" 
                  ? "bg-slate-800 text-white shadow shadow-white/5 border border-slate-700" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50"
              }`}
            >
              <Smartphone className="w-4 h-4 text-orange-400" />
              Sửa Nội Dung
            </button>
            <button
              onClick={() => setActiveTab("code")}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all duration-200 ${
                activeTab === "code" 
                  ? "bg-slate-800 text-white shadow shadow-white/5 border border-slate-700" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50"
              }`}
            >
              <FileCode className="w-4 h-4 text-rose-450 text-rose-400" />
              Mã HTML Elementor
            </button>
            <button
              onClick={() => setActiveTab("orders")}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all duration-200 relative ${
                activeTab === "orders" 
                  ? "bg-slate-800 text-white shadow shadow-white/5 border border-slate-700" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50"
              }`}
            >
              <ClipboardList className="w-4 h-4 text-sky-400" />
              Đơn hàng
              {orders.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[9.5px] rounded-full w-5 h-5 flex items-center justify-center font-black animate-bounce shadow">
                  {orders.length}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab("guide")}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all duration-200 ${
                activeTab === "guide" 
                  ? "bg-slate-800 text-white shadow shadow-white/5 border border-slate-700" 
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50"
              }`}
            >
              <HelpCircle className="w-4 h-4 text-emerald-400" />
              Hướng dẫn
            </button>
          </nav>

          {/* TAB PANEL CONTENT */}
          <div className="bg-slate-950/80 border border-slate-800 p-5 rounded-2xl shadow-xl min-h-[500px]">
            
            {/* 1. EDIT CONFIG PANEL */}
            {activeTab === "edit" && (
              <div className="space-y-6">
                
                {/* SUB TAB SELECTORS FOR ORGANIZED EDITING */}
                <div className="flex bg-slate-900 p-1 rounded-xl gap-1 border border-slate-800/60 overflow-x-auto">
                  <button
                    onClick={() => setActiveSubTab("general")}
                    className={`flex-1 py-1.5 px-2.5 rounded-lg text-[11px] font-bold whitespace-nowrap transition ${
                      activeSubTab === "general" ? "bg-slate-800 text-white" : "text-slate-450 text-slate-450 font-semibold"
                    }`}
                  >
                    Thông tin Chung
                  </button>
                  <button
                    onClick={() => setActiveSubTab("problems")}
                    className={`flex-1 py-1.5 px-2.5 rounded-lg text-[11px] font-bold whitespace-nowrap transition ${
                      activeSubTab === "problems" ? "bg-slate-800 text-white" : "text-slate-450"
                    }`}
                  >
                    Giải Pháp & Lợi ích
                  </button>
                  <button
                    onClick={() => setActiveSubTab("packages")}
                    className={`flex-1 py-1.5 px-2.5 rounded-lg text-[11px] font-bold whitespace-nowrap transition ${
                      activeSubTab === "packages" ? "bg-slate-800 text-white" : "text-slate-450"
                    }`}
                  >
                    Mức Giá Sách
                  </button>
                  <button
                    onClick={() => setActiveSubTab("testimonials")}
                    className={`flex-1 py-1.5 px-2.5 rounded-lg text-[11px] font-bold whitespace-nowrap transition ${
                      activeSubTab === "testimonials" ? "bg-slate-800 text-white" : "text-slate-450"
                    }`}
                  >
                    Ý Kiến Độc Giả
                  </button>
                </div>

                {/* SUBTAB: GENERAL */}
                {activeSubTab === "general" && (
                  <div className="space-y-4">
                    <h3 className="text-xs font-black text-white bg-slate-900 border-l-4 border-orange-500 py-1.5 px-3 uppercase tracking-wide">
                      Cấu hình Tiêu đề & Bìa sách
                    </h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Tiêu Đề Header</label>
                        <input
                          type="text"
                          value={config.headerTitle}
                          onChange={e => handleInputChange("headerTitle", e.target.value)}
                          className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-orange-500 focus:outline-none"
                          placeholder="e.g. CÂU LẠC BỘ SÁCH TINH HOA"
                        />
                      </div>
                      <div>
                        <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Dòng Chạy thông báo</label>
                        <input
                          type="text"
                          value={config.headerNotice}
                          onChange={e => handleInputChange("headerNotice", e.target.value)}
                          className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-orange-500 focus:outline-none"
                          placeholder="Thông báo khẩn về ship, thanh toán..."
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Tiêu Đề Sách</label>
                      <input
                        type="text"
                        value={config.bookTitle}
                        onChange={e => handleInputChange("bookTitle", e.target.value)}
                        className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-orange-500 focus:outline-none font-bold text-white uppercase"
                        placeholder="TÊN CUỐN SÁCH RIÊNG CỦA BẠN"
                      />
                    </div>

                    <div>
                      <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Mô tả Phụ lôi cuốn (Subtitle)</label>
                      <textarea
                        value={config.bookSubtitle}
                        onChange={e => handleInputChange("bookSubtitle", e.target.value)}
                        rows={3}
                        className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-orange-500 focus:outline-none resize-none leading-relaxed"
                        placeholder="Mô tả tóm tắt nội dung để gia tăng sự kích thích mua hàng..."
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Đánh giá Sao (Score)</label>
                        <input
                          type="text"
                          value={config.ratingScore}
                          onChange={e => handleInputChange("ratingScore", e.target.value)}
                          className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-orange-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Số lượt bình chọn</label>
                        <input
                          type="text"
                          value={config.ratingCount}
                          onChange={e => handleInputChange("ratingCount", e.target.value)}
                          className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-orange-500"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Thời gian đếm ngược (Phút)</label>
                        <input
                          type="number"
                          value={config.countdownMinutes}
                          onChange={e => handleInputChange("countdownMinutes", parseInt(e.target.value) || 15)}
                          className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-orange-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Phần trăm giảm tối đa</label>
                        <input
                          type="number"
                          value={config.discountPercentage}
                          onChange={e => handleInputChange("discountPercentage", parseInt(e.target.value) || 50)}
                          className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-orange-500"
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider">
                          Liên kết ảnh bìa sách 3D (Bản WordPress / Unsplash)
                        </label>
                        <span className="text-[9.5px] text-slate-500">Mẹo: Sử dụng tỷ lệ đứng như 3:4</span>
                      </div>
                      <input
                        type="text"
                        value={config.bookCoverUrl}
                        onChange={e => handleInputChange("bookCoverUrl", e.target.value)}
                        className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-orange-500 focus:outline-none text-blue-400"
                        placeholder="Dán link ảnh bìa sách ở đây..."
                      />
                      <p className="text-[10px] text-slate-500 mt-1">Khi dán vào WordPress, bạn có thể tải ảnh lên Media Library rồi dán link vào đây để xem thử trực tiếp.</p>
                    </div>

                    <h3 className="text-xs font-black text-white bg-slate-900 border-l-4 border-emerald-500 py-1.5 px-3 uppercase tracking-wide mt-6">
                      Liên kết Google Sheet & Thông tin Nhà xuất bản
                    </h3>

                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="block text-[10.5px] font-bold text-emerald-400 uppercase tracking-wider">
                          Đường dẫn Web App Google Sheet (Webhook)
                        </label>
                        <button 
                          type="button" 
                          onClick={testWebhookDirect} 
                          className="text-[9.5px] bg-slate-800 hover:bg-slate-700 text-teal-400 border border-slate-700 py-0.5 px-2 rounded-lg"
                        >
                          Kiểm tra thử link này
                        </button>
                      </div>
                      <input
                        type="text"
                        value={config.googleSheetUrl}
                        onChange={e => handleInputChange("googleSheetUrl", e.target.value)}
                        className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-emerald-500 text-teal-400"
                        placeholder="Link Web App từ Google Apps Script..."
                      />
                      <p className="text-[10px] text-slate-500 mt-1">Khi khách mua trên Preview di động, dữ liệu sẽ được bắn tới link này. Xem cột <strong>Hướng dẫn</strong> để biết cách lấy link.</p>
                    </div>

                    <div>
                      <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Tên Công Ty chân trang</label>
                      <input
                        type="text"
                        value={config.companyName}
                        onChange={e => handleInputChange("companyName", e.target.value)}
                        className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-orange-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Địa chỉ liên hệ</label>
                      <input
                        type="text"
                        value={config.companyAddress}
                        onChange={e => handleInputChange("companyAddress", e.target.value)}
                        className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-orange-500"
                      />
                    </div>

                    <div>
                      <label className="block text-[10.5px] font-bold text-slate-400 uppercase tracking-wider mb-1">Liên hệ Hotline / MST</label>
                      <input
                        type="text"
                        value={config.companyContact}
                        onChange={e => handleInputChange("companyContact", e.target.value)}
                        className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl focus:border-orange-500"
                      />
                    </div>
                  </div>
                )}

                {/* SUBTAB: PROBLEMS & SOLUTIONS */}
                {activeSubTab === "problems" && (
                  <div className="space-y-5">
                    
                    {/* PROBLEMS LIST */}
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <label className="block text-xs font-bold text-white uppercase tracking-wider">
                          Danh sách Nỗi Đau Khách Hàng (Problems - Vấn đề)
                        </label>
                        <button
                          type="button"
                          onClick={() => addListItem("problems", "Mô tả một nỗi sợ hãi hoặc khó khăn mới mà độc giả đang gặp phải...")}
                          className="text-[10.5px] text-orange-400 flex items-center gap-1 hover:underline"
                        >
                          <Plus className="w-3.5 h-3.5" /> Thêm điểm mới
                        </button>
                      </div>
                      
                      <input
                        type="text"
                        value={config.problemTitle}
                        onChange={e => handleInputChange("problemTitle", e.target.value)}
                        className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl text-white font-bold"
                        placeholder="Tiêu đề khối vấn đề"
                      />

                      <div className="space-y-2 max-h-[180px] overflow-y-auto pr-1">
                        {config.problems.map((prob, idx) => (
                          <div key={idx} className="flex gap-2 items-center">
                            <span className="text-[10px] text-slate-500 font-mono">#{idx+1}</span>
                            <input
                              type="text"
                              value={prob}
                              onChange={e => handleListItemChange("problems", idx, e.target.value)}
                              className="flex-1 text-xs p-2.5 bg-slate-900 border border-slate-800 rounded-lg text-slate-300"
                            />
                            <button
                              type="button"
                              onClick={() => removeListItem("problems", idx)}
                              className="text-slate-500 hover:text-red-500"
                            >
                              <Trash className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* SOLUTION CARDS EXPLAINED */}
                    <div className="space-y-3 mt-4">
                      <label className="block text-xs font-bold text-white uppercase tracking-wider">
                        Khối Giải Pháp (Công dụng đặc thù của cuốn sách)
                      </label>
                      <input
                        type="text"
                        value={config.solutionTitle}
                        onChange={e => handleInputChange("solutionTitle", e.target.value)}
                        className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl text-white font-bold mb-2"
                        placeholder="Tiêu đề khối giải pháp"
                      />

                      <div className="grid grid-cols-1 gap-3.5 max-h-[220px] overflow-y-auto pr-1">
                        {config.solutions.map((sol, idx) => (
                          <div key={idx} className="bg-slate-900 border border-slate-800 p-3 rounded-xl space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-[10.5px] font-bold text-emerald-400">GIẢI PHÁP SỐ {idx+1}</span>
                            </div>
                            <input
                              type="text"
                              value={sol.title}
                              onChange={e => handleSolutionChange(idx, "title", e.target.value)}
                              className="w-full p-2 bg-slate-800 text-xs font-bold text-white rounded-lg focus:outline-none"
                              placeholder="Tiêu đề giải pháp..."
                            />
                            <textarea
                              value={sol.desc}
                              onChange={e => handleSolutionChange(idx, "desc", e.target.value)}
                              rows={2}
                              className="w-full p-2 bg-slate-800 text-xs text-slate-300 rounded-lg focus:outline-none resize-none leading-relaxed"
                              placeholder="Mô tả sự đột phá cuốn sách mang lại..."
                            />
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* CORE BENEFITS */}
                    <div className="space-y-3 pt-3">
                      <div className="flex justify-between items-center">
                        <label className="block text-xs font-bold text-white uppercase tracking-wider">
                          Đặc Quyền Nhận Được (Benefits - Sách tặng/Kỹ năng nhận được)
                        </label>
                        <button
                          type="button"
                          onClick={() => addListItem("benefits", "Thêm một lợi ích hoặc quà tặng đính kèm cực chất khác...")}
                          className="text-[10.5px] text-orange-400 flex items-center gap-1 hover:underline"
                        >
                          <Plus className="w-3.5 h-3.5" /> Thêm điểm mới
                        </button>
                      </div>

                      <input
                        type="text"
                        value={config.benefitsTitle}
                        onChange={e => handleInputChange("benefitsTitle", e.target.value)}
                        className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl text-white font-bold"
                        placeholder="Tiêu đề khối lợi ích"
                      />

                      <div className="space-y-2 max-h-[180px] overflow-y-auto pr-1">
                        {config.benefits.map((benefit, idx) => (
                          <div key={idx} className="flex gap-2 items-center">
                            <span className="text-[10px] text-slate-500 font-mono">#{idx+1}</span>
                            <input
                              type="text"
                              value={benefit}
                              onChange={e => handleListItemChange("benefits", idx, e.target.value)}
                              className="flex-1 text-xs p-2.5 bg-slate-900 border border-slate-800 rounded-lg text-slate-300"
                            />
                            <button
                              type="button"
                              onClick={() => removeListItem("benefits", idx)}
                              className="text-slate-500 hover:text-red-500"
                            >
                              <Trash className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>
                )}

                {/* SUBTAB: PACKAGES EDITING */}
                {activeSubTab === "packages" && (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider">Cấu hình các Combo mua Sách</h4>
                        <p className="text-[10px] text-slate-500 mt-0.5">Khuyên dùng nên có 3 gói: Trải nghiệm, Best Seller, Tiết kiệm nhất</p>
                      </div>
                      <button
                        type="button"
                        onClick={addPackage}
                        className="bg-slate-800 text-orange-400 border border-slate-700 text-[10.5px] px-3 py-1.5 rounded-lg flex items-center gap-1 hover:bg-slate-700"
                      >
                        <Plus className="w-3.5 h-3.5" /> Thêm Gói Mới
                      </button>
                    </div>

                    <input
                      type="text"
                      value={config.packagesTitle}
                      onChange={e => handleInputChange("packagesTitle", e.target.value)}
                      className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl text-white font-bold mb-4"
                      placeholder="Tiêu đề hộp lựa chọn"
                    />

                    <div className="space-y-4 max-h-[440px] overflow-y-auto pr-1">
                      {config.packages.map((pkg, idx) => (
                        <div key={pkg.id} className="bg-slate-900 border border-slate-800 p-4 rounded-2xl relative space-y-3">
                          <button
                            type="button"
                            onClick={() => removePackage(idx)}
                            className="absolute top-4 right-4 text-slate-500 hover:text-red-500"
                            title="Xóa gói này"
                          >
                            <Trash2 className="w-4.5 h-4.5" />
                          </button>

                          <div className="flex items-center gap-2">
                            <span className="w-5 h-5 rounded bg-slate-800 text-slate-400 flex items-center justify-center font-mono text-xs">
                              {idx+1}
                            </span>
                            <span className="text-[11px] font-extrabold uppercase text-orange-400">GÓI SẢN PHẨM</span>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[10px] font-semibold text-slate-500 mb-1">TÊN GÓI SÁCH / COMBO</label>
                              <input
                                type="text"
                                value={pkg.name}
                                onChange={e => handlePackageChange(idx, "name", e.target.value)}
                                className="w-full text-xs p-2.5 bg-slate-800 border border-slate-700 rounded-lg font-bold"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] font-semibold text-slate-500 mb-1">HUY HIỆU GỢI Ý (BADGE)</label>
                              <input
                                type="text"
                                value={pkg.badge || ""}
                                onChange={e => handlePackageChange(idx, "badge", e.target.value)}
                                className="w-full text-xs p-2.5 bg-slate-800 border border-slate-700 rounded-lg placeholder-slate-600"
                                placeholder="Ví dụ: BÁN CHẠY, HOT..."
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[10px] font-semibold text-slate-500 mb-1">GIÁ GỐC (CHƯA GIẢM)</label>
                              <input
                                type="number"
                                value={pkg.originalPrice}
                                onChange={e => handlePackageChange(idx, "originalPrice", parseInt(e.target.value) || 0)}
                                className="w-full text-xs p-2.5 bg-slate-800 border border-slate-700 rounded-lg"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] font-semibold text-slate-500 mb-1">GIÁ ƯU ĐÃI (MUA NGAY)</label>
                              <input
                                type="number"
                                value={pkg.salePrice}
                                onChange={e => handlePackageChange(idx, "salePrice", parseInt(e.target.value) || 0)}
                                className="w-full text-xs p-2.5 bg-slate-800 border border-slate-700 rounded-lg font-bold text-emerald-400"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] font-semibold text-slate-500 mb-1">QUÀ TẶNG & QUYỀN LỢI ĐI KÈM COMBO</label>
                            <input
                              type="text"
                              value={pkg.description}
                              onChange={e => handlePackageChange(idx, "description", e.target.value)}
                              className="w-full text-xs p-2.5 bg-slate-800 border border-slate-700 rounded-lg"
                              placeholder="e.g. Miễn phí ship, Tặng bản PDF thực hành..."
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* SUBTAB: TESTIMONIALS */}
                {activeSubTab === "testimonials" && (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider">Đánh giá tiêu biểu từ Độc Giả</h4>
                        <p className="text-[10px] text-slate-500 mt-0.5">Nên chọn những feedback bám sát tính năng và chất lượng sách</p>
                      </div>
                      <button
                        type="button"
                        onClick={addTestimonial}
                        className="bg-slate-800 text-orange-400 border border-slate-700 text-[10.5px] px-3 py-1.5 rounded-lg flex items-center gap-1 hover:bg-slate-700"
                      >
                        <Plus className="w-3.5 h-3.5" /> Thêm Đánh Giá
                      </button>
                    </div>

                    <input
                      type="text"
                      value={config.testimonialsTitle}
                      onChange={e => handleInputChange("testimonialsTitle", e.target.value)}
                      className="w-full text-xs p-3 bg-slate-900 border border-slate-800 rounded-xl text-white font-bold"
                      placeholder="Tiêu đề đánh giá khách hàng"
                    />

                    <div className="space-y-4 max-h-[440px] overflow-y-auto pr-1">
                      {config.testimonials.map((test, idx) => (
                        <div key={test.id} className="bg-slate-900 border border-slate-800 p-4 rounded-xl relative space-y-3">
                          <button
                            type="button"
                            onClick={() => removeTestimonial(idx)}
                            className="absolute top-4 right-4 text-slate-500 hover:text-red-500"
                            title="Xóa đánh giá này"
                          >
                            <Trash className="w-4.5 h-4.5" />
                          </button>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[10px] font-semibold text-slate-500 mb-1">TÊN KHÁCH HÀNG</label>
                              <input
                                type="text"
                                value={test.author}
                                onChange={e => handleTestimonialChange(idx, "author", e.target.value)}
                                className="w-full text-xs p-2.5 bg-slate-800 border border-slate-700 rounded-lg font-bold"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] font-semibold text-slate-400 mb-1">THỜI GIAN ĐĂNG</label>
                              <input
                                type="text"
                                value={test.date}
                                onChange={e => handleTestimonialChange(idx, "date", e.target.value)}
                                className="w-full text-xs p-2.5 bg-slate-800 border border-slate-700 rounded-lg placeholder-slate-400"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="block text-[10px] font-semibold text-slate-500 mb-1">LINK ẢNH AVATAR</label>
                              <input
                                type="text"
                                value={test.avatar}
                                onChange={e => handleTestimonialChange(idx, "avatar", e.target.value)}
                                className="w-full text-xs p-2.5 bg-slate-800 border border-slate-700 rounded-lg text-blue-400"
                              />
                            </div>
                            <div className="flex items-center gap-1.5 pt-4">
                              <input
                                type="checkbox"
                                id={`verified-${test.id}`}
                                checked={test.verified}
                                onChange={e => handleTestimonialChange(idx, "verified", e.target.checked)}
                                className="w-4 h-4 text-orange-500 rounded border-slate-700 focus:ring-slate-800 bg-slate-800"
                              />
                              <label htmlFor={`verified-${test.id}`} className="text-[10.5px] font-bold text-emerald-400 uppercase">
                                Huy hiệu "Đã mua"
                              </label>
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] font-semibold text-slate-500 mb-1">NỘI DUNG FEEDBACK CHI TIẾT</label>
                            <textarea
                              value={test.content}
                              onChange={e => handleTestimonialChange(idx, "content", e.target.value)}
                              rows={3}
                              className="w-full text-xs p-2.5 bg-slate-800 border border-slate-700 rounded-lg resize-none leading-relaxed"
                              placeholder="Trải nghiệm đọc chân thực..."
                            />
                          </div>
                        </div>
                      ))}
                    </div>

                  </div>
                )}

              </div>
            )}

            {/* 2. CUSTOM HTML DISPLAY & EXPORTER */}
            {activeTab === "code" && (
              <div className="space-y-4">
                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div>
                    <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                      <FileCode className="w-4 h-4 text-rose-400" />
                      MÃ CUSTOM HTML ELEMENTOR ĐÃ BIÊN DỊCH
                    </h4>
                    <p className="text-[10px] text-zinc-400 mt-1">
                      Mã này tích hợp hoàn hảo CSS Layout, CDNs, Animations và Javascript xử lý. Có thể copy dán thẳng.
                    </p>
                  </div>
                  
                  <div className="flex gap-2 w-full sm:w-auto">
                    <button
                      type="button"
                      onClick={handleCopyCode}
                      className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-750 text-white border border-slate-700 py-2 px-3.5 rounded-lg text-xs font-bold transition"
                    >
                      {isCopied ? <Check className="w-4.5 h-4.5 text-emerald-400" /> : <Copy className="w-4.5 h-4.5" />}
                      {isCopied ? "Đã sao chép!" : "Sao chép Code"}
                    </button>
                    <button
                      type="button"
                      onClick={handleDownloadCode}
                      className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white py-2 px-3.5 rounded-lg text-xs font-bold transition"
                    >
                      <Download className="w-4.5 h-4.5" />
                      Tải file .html
                    </button>
                  </div>
                </div>

                <div className="relative">
                  <div className="absolute top-3 right-3 bg-slate-900/80 border border-slate-800 text-[10px] text-rose-300 font-mono px-2 py-1 rounded">
                    HTML + Tailwind CSS CDN + JS
                  </div>
                  <pre className="p-4 bg-slate-950 border border-slate-800 rounded-xl text-slate-350 text-[10px] font-mono leading-relaxed overflow-x-auto max-h-[440px] text-slate-300">
                    <code>
                      {generateElementorHTML(config)}
                    </code>
                  </pre>
                </div>

                <div className="bg-amber-500/10 border border-amber-500/20 p-3.5 rounded-xl text-amber-200/95 leading-relaxed text-[11px] flex items-start gap-2.5">
                  <span className="text-amber-400 font-extrabold flex-shrink-0 mt-0.5">⚠️ CHÚ Ý:</span>
                  <div>
                    Mã nguồn trên đã được đồng bộ tự động với các chỉnh sửa bạn vừa làm trên tab <strong>Sửa Nội dung</strong>. Bạn chỉ cần sao chép đơ thể dán thẳng vào widget <strong>HTML (hoặc Custom HTML)</strong> của Elementor là Landingpage sẽ chạy lung linh lập tức.
                  </div>
                </div>
              </div>
            )}

            {/* 3. ORDER MANAGEMENT PANEL */}
            {activeTab === "orders" && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div>
                    <h4 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                      <ClipboardList className="w-4.5 h-4.5 text-sky-400" />
                      DANH SÁCH ĐƠN ĐĂNG KÝ HÀNG THỰC TẾ
                    </h4>
                    <p className="text-[10px] text-zinc-400 mt-1">
                      Các đơn điền từ form thử nghiệm ở iPhone Preview bên phải sẽ tự thu nạp tại đây để quản trị.
                    </p>
                  </div>

                  {orders.length > 0 && (
                    <div className="flex gap-2 w-full sm:w-auto">
                      <button
                        onClick={exportAllOrdersCSV}
                        className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 py-1.5 px-3 rounded-xl text-xs font-semibold text-white transition"
                      >
                        <Download className="w-3.5 h-3.5" /> Xuất Excel CSV
                      </button>
                      <button
                        onClick={clearAllOrders}
                        className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 bg-red-650 hover:bg-red-600/15 text-red-400 border border-red-500/20 py-1.5 px-3 rounded-xl text-xs font-semibold transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Xóa tất cả
                      </button>
                    </div>
                  )}
                </div>

                <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900/40">
                  {orders.length === 0 ? (
                    <div className="p-8 text-center text-slate-500 text-xs">
                      <Smartphone className="w-10 h-10 mx-auto text-slate-600 mb-3 animate-pulse" />
                      <p className="font-semibold text-slate-400">Chưa có đơn hàng đặt mua thử</p>
                      <p className="text-[10.5px] mt-1 text-slate-500">Mẹo: Thử cuộn xuống cuối màn hình điện thoại bên phải, điền thông tin và bấm 'Xác nhận đặt hàng' để kiểm định dòng chảy dữ liệu!</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-800/80 max-h-[380px] overflow-y-auto">
                      {orders.map(order => (
                        <div key={order.id} className="p-4 hover:bg-slate-850/50 transition">
                          <div className="flex justify-between items-start gap-2 mb-2">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="bg-orange-500/20 text-orange-400 text-[10px] font-black font-mono px-2 py-0.5 rounded-md border border-orange-500/10">
                                  #{order.id}
                                </span>
                                <span className="text-xs font-bold text-white">{order.customerName}</span>
                              </div>
                              <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                                <Calendar className="w-3 h-3 text-slate-500" /> Ngày đặt: {order.createdAt}
                              </p>
                            </div>
                            <span className="text-xs font-black text-rose-450 text-rose-400">{formatMoney(order.totalPrice)}</span>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1.5 mt-2.5 text-[10.5px] text-zinc-300 border-t border-slate-800/40 pt-2.5 leading-relaxed">
                            <p className="flex items-center gap-1.5"><Phone className="w-3 h-3 text-slate-500 flex-shrink-0" /> <span className="font-semibold text-slate-400">SĐT:</span> {order.customerPhone}</p>
                            <p className="flex items-center gap-1.5"><Layers className="w-3 h-3 text-slate-500 flex-shrink-0" /> <span className="font-semibold text-slate-400">Gói sách:</span> {order.selectedPackageName}</p>
                            <p className="flex items-start gap-1.5 md:col-span-2"><MapPin className="w-3 h-3 text-slate-500 flex-shrink-0 mt-0.5" /> <span className="font-semibold text-slate-400">Địa chỉ:</span> {order.customerAddress}</p>
                            {order.note && (
                              <p className="flex items-start gap-1.5 md:col-span-2 italic text-amber-300/90 bg-amber-500/5 p-1.5 rounded border border-amber-500/10 mt-1">
                                <MessageSquare className="w-3 h-3 text-amber-500 flex-shrink-0 mt-0.5" /> 
                                <span className="font-bold text-amber-400">Lưu ý:</span> {order.note}
                              </p>
                            )}
                          </div>

                          <div className="flex justify-end gap-2 mt-3 pt-2.5 border-t border-slate-800/20">
                            <button
                              onClick={() => deleteOrder(order.id)}
                              className="text-slate-550 text-slate-500 hover:text-red-400 text-[10px]"
                            >
                              Xóa đơn này
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {webhookStatus !== "idle" && (
                  <div className={`p-3.5 rounded-xl text-xs font-medium border flex items-center gap-2.5 ${
                    webhookStatus === "sending" ? "bg-sky-500/10 border-sky-500/20 text-sky-450" :
                    webhookStatus === "success" ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-450" :
                    "bg-red-500/10 border-red-500/20 text-red-450"
                  }`}>
                    {webhookStatus === "sending" && <span className="animate-spin inline-block w-4 h-4 rounded-full border-2 border-sky-400 border-t-transparent"></span>}
                    {webhookStatus === "success" && <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />}
                    {webhookStatus === "error" && <span className="text-red-400 font-bold flex-shrink-0">⚠️ Lỗi:</span>}
                    <div>{webhookMessage}</div>
                  </div>
                )}
              </div>
            )}

            {/* 4. SETUP MANUAL TUTORIAL */}
            {activeTab === "guide" && (
              <div className="space-y-5 leading-relaxed text-slate-300 text-xs">
                
                {/* ELEMENTOR LAYOUT SETUP */}
                <div className="space-y-2.5 border-b border-slate-800 pb-4">
                  <h4 className="text-xs font-black text-rose-400 uppercase tracking-widest flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded bg-rose-500/20 text-rose-450 flex items-center justify-center font-bold text-[9.5px]">1</span>
                    CÁCH THIẾT LẬP LAYOUT TRONG ELEMENTOR (WORDPRESS)
                  </h4>
                  <ul className="list-disc pl-5 space-y-1.5 text-[11px] text-zinc-300 font-medium">
                    <li>
                      <strong>Tạo Section trống:</strong> Mở giao diện Elementor, kéo một section có <strong className="text-white">1 Cột duy nhất (Single Column)</strong> vào trang thiết kế landing.
                    </li>
                    <li>
                      <strong>Thiết lập khung hẹp:</strong> Trong cài đặt Section / Layout, tại mục <strong className="text-white">Nội dung rộng (Content Width)</strong> chọn <em className="text-orange-400">Hộp (Boxed)</em> và đặt chiều rộng là <strong className="text-white">480px</strong>. (Nếu bạn muốn giao diện tuyệt mỹ dạng dải dọc tập trung trên điện thoại).
                    </li>
                    <li>
                      <strong>Thiết lập Lề (Padding/Margin):</strong> Sang tab <em className="text-white">Nâng cao (Advanced)</em>:
                      <ul className="list-circle pl-5 mt-1 space-y-1 text-slate-400">
                        <li>Đặt toàn bộ <strong className="text-white">Margin = 0</strong> để tránh khoảng trống viền rìa trang.</li>
                        <li>Đặt <strong className="text-white">Padding = 0px</strong> để trang bìa, đầu trang hiển thị tràn khung đẹp mắt nhất từ di động.</li>
                      </ul>
                    </li>
                    <li>
                      <strong>Chèn Khối Custom HTML:</strong> Tìm Widget tên là <strong className="text-orange-400">"HTML"</strong> từ trình tìm kiếm của Elementor, kéo & thả thẳng vào cột vừa tạo.
                    </li>
                    <li>
                      <strong>Dán mã:</strong> Nhấp vào tab <strong className="text-rose-400">"Mã HTML Elementor"</strong> của Builder này, bấm nút sao chép và dán thẳng vào ô văn bản Custom HTML của Elementor. Bấm <strong>Cập nhật (Publish)</strong> là trang bán sách chính thức hoạt động hoàn mỹ!
                    </li>
                  </ul>
                </div>

                {/* GOOGLE SHEETS CONNECTOR EXPLAINED */}
                <div className="space-y-2.5">
                  <h4 className="text-xs font-black text-emerald-400 uppercase tracking-widest flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded bg-emerald-500/20 text-emerald-450 flex items-center justify-center font-bold text-[9.5px]">2</span>
                    ĐỒNG BỘ DỮ LIỆU ĐẶT HÀNG SANG GOOGLE SHEET (MIỄN PHÍ)
                  </h4>
                  <p className="text-[11px] text-slate-450">Để tránh mất chi phí CRM đắt đỏ, hãy làm theo hướng dẫn miễn phí tuyệt hảo sau:</p>
                  
                  <nav className="space-y-2 text-[11px] text-slate-350">
                    <p><strong>Bước A:</strong> Tạo một trang <strong className="text-white">Google Sheet</strong> mới. Thiết lập các tên cột sau tại hàng số 1 từ trái qua phải:</p>
                    <div className="bg-slate-950 p-2 border border-slate-800 rounded font-mono text-[9px] text-emerald-400 flex flex-wrap gap-1.5">
                      <span>A1: Họ và Tên</span> | <span>B1: Số Điện Thoại</span> | <span>C1: Địa Chỉ Nhận</span> | <span>D1: Gói Sản Phẩm</span> | <span>E1: Tổng Tiền</span> | <span>F1: Ghi Chú</span> | <span>G1: Ngày Đặt</span>
                    </div>

                    <p><strong>Bước B:</strong> Trên thanh công cụ, chọn <strong className="text-white">Tiện ích mở rộng (Extensions)</strong> &gt; Chọn <strong className="text-orange-400">Apps Script</strong>.</p>
                    <p><strong>Bước C:</strong> Xóa mọi mã trong ô soạn thảo hiện tại, sao chép & dán chính xác đoạn mã sau:</p>
                    
                    <pre className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-300 font-mono text-[9.5px] overflow-x-auto leading-normal">
{`function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  
  // Thêm dữ liệu dòng mới
  sheet.appendRow([
    data.fullName,
    data.phoneNumber,
    data.shippingAddress,
    data.packageName,
    data.totalPrice,
    data.noteMessage,
    data.currentTime
  ]);
  
  return ContentService.createTextOutput(JSON.stringify({"status":"success"}))
    .setMimeType(ContentService.MimeType.JSON);
}`}
                    </pre>

                    <p><strong>Bước D:</strong> Bấm nút hình 💾 để <strong className="text-white">Lưu dự án</strong>.</p>
                    <p><strong>Bước E:</strong> Bấm nút <strong className="text-emerald-400">Triển khai (Deploy)</strong> ở góc trên bên phải &gt; Chọn <strong className="text-white">Triển khai mới (New deployment)</strong>.</p>
                    <ul className="list-disc pl-5 mt-1 space-y-1 text-slate-400">
                      <li>Tại "Loại cấu hình", chọn bánh răng cưa &gt; Chọn <strong className="text-white">Ứng dụng Web (Web app)</strong>.</li>
                      <li>Tại ô "Người có quyền truy cập" (Who has access), bạn <strong>BẮT BUỘC</strong> phải chọn mục <strong className="text-red-400 font-bold">"Bất kỳ ai" (Anyone)</strong>.</li>
                    </ul>
                    <p className="mt-1"><strong>Bước F:</strong> Bấm "Triển khai", cấp quyền đăng nhập tài khoản Google Drive của bạn khi được hỏi, sau đó sao chép đoạn <strong className="text-emerald-400">"URL ứng dụng Web" (Web app URL)</strong> nhận được, dán trực tiếp vào ô <strong className="text-orange-400">Webhook Google Sheet</strong> trong Tab 1 của ứng dụng này.</p>
                  </nav>
                </div>

              </div>
            )}

          </div>
        </div>

        {/* RIGHT SCREEN - REALTIME PREVIEW ON PHONE CONTAINER */}
        <div className="flex-1 bg-slate-950 flex justify-center items-center p-3 md:p-6 overflow-y-auto selection:bg-orange-500/20">
          
          {/* PHONE CONTAINER BODY */}
          <div className="relative w-full max-w-[390px] h-[760px] bg-slate-900 rounded-[44px] p-2.5 shadow-[0_25px_50px_-12px_rgba(0,0,0,0.8)] border-[6px] border-slate-800 flex flex-col overflow-hidden">
            
            {/* PHYSICAL NOTCH AND SPEECH RAIL */}
            <div className="absolute top-2.5 left-1/2 transform -translate-x-1/2 w-32 h-5 bg-slate-900 rounded-b-2xl z-30 flex justify-between items-center px-4">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-700"></span>
              <div className="w-10 h-1 bg-slate-800 rounded-full"></div>
              <span className="w-1 h-1 rounded-full bg-slate-700"></span>
            </div>

            {/* LIVE DIGITAL STATUS BAR */}
            <div className="bg-slate-950 text-white text-[10.5px] font-bold px-7 pt-4 pb-2.5 flex justify-between items-center z-25 relative shrink-0">
              <span>08:15 Sáng</span>
              <div className="flex items-center gap-1">
                <span>5G</span>
                <div className="w-4.5 h-2.5 border border-white/60 p-0.5 rounded flex items-center">
                  <div className="w-full h-full bg-emerald-400 rounded-xs"></div>
                </div>
              </div>
            </div>

            {/* INTERNAL PHONE SCREEN PORT */}
            <div className="flex-1 bg-white rounded-[32px] overflow-y-auto scrollbar-none relative pb-16 text-slate-800 leading-snug text-sm select-none">
              
              {/* TOP HEADER */}
              <div className="bg-slate-900 text-white py-2 px-3 text-center sticky top-0 z-40 shadow">
                <div className="flex items-center justify-between text-[11px] font-bold">
                  <div className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping"></span>
                    <span className="text-[10px] text-orange-400 tracking-wide uppercase">{config.headerTitle}</span>
                  </div>
                  <span className="bg-orange-500 text-white text-[8px] px-1.5 py-0.2 rounded-full font-black">
                    UƯ ĐÃI GIẢM {config.discountPercentage}%
                  </span>
                </div>
                <div className="bg-white/10 text-[9px] text-slate-350 text-white opacity-95 text-center mt-1 py-0.5 font-semibold leading-tight capitalize truncate">
                  {config.headerNotice}
                </div>
              </div>

              {/* HERO INSIDE PHONE PORT */}
              <div className="pt-5 pb-6 px-3 bg-gradient-to-b from-slate-50 to-white border-b border-slate-100 text-center">
                
                {/* Visual Stars Rating */}
                <div className="inline-flex items-center gap-1 bg-amber-500/10 border border-amber-500/20 px-2.5 py-0.5 rounded-full mb-3">
                  <span className="text-amber-500 text-[10px]">★ ★ ★ ★ ★</span>
                  <span className="text-[9.5px] font-black text-amber-900">{config.ratingScore}/5 ({config.ratingCount}+ đã mua)</span>
                </div>

                <h2 className="text-base font-black text-slate-900 leading-snug uppercase px-1">
                  {config.bookTitle}
                </h2>
                
                <p className="text-[11px] text-slate-450 text-slate-500 font-medium leading-relaxed mt-2 mb-4 px-2">
                  {config.bookSubtitle}
                </p>

                {/* Cover 3D Render inside Mobile layout */}
                <div className="flex justify-center mb-6 relative">
                  <div className="absolute inset-0 bg-orange-100/40 rounded-full blur-2xl w-40 h-40 mx-auto"></div>
                  <img 
                    src={config.bookCoverUrl} 
                    alt={config.bookTitle}
                    className="w-40 h-52 object-cover rounded-lg shadow-xl relative z-10 border border-slate-100 floating-book"
                    onError={(e) => {
                      // fallback nicely if image fails to load
                      e.currentTarget.src = "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=600";
                    }}
                  />
                  
                  {/* Floating Discount Badge */}
                  <div className="absolute right-12 bottom-2 bg-gradient-to-br from-red-600 to-orange-500 text-white rounded-full w-14 h-14 flex flex-col justify-center items-center font-extrabold shadow-lg z-20 border-2 border-white transform rotate-12">
                    <span className="text-[8px] font-bold">GIẢM</span>
                    <span className="text-sm leading-none">{config.discountPercentage}%</span>
                    <span className="text-[7px]">CHỈ NAY</span>
                  </div>
                </div>

                {/* Live Count down alert box */}
                <div className="bg-red-50/80 border border-red-100 rounded-xl p-3 mb-5 mx-1">
                  <p className="text-[10px] font-bold text-red-650 text-red-600 uppercase flex items-center justify-center gap-1 mb-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse inline-block"></span>
                    Giá ưu đãi kết thúc sau chỉ còn:
                  </p>
                  <div className="flex justify-center gap-2 max-w-[180px] mx-auto">
                    <div className="bg-slate-950 text-white py-1 px-2 rounded-md font-mono text-xs font-black">
                      {String(countdown.hrs).padStart(2, '0')}<span className="text-[7px] text-slate-400 block font-normal">Giờ</span>
                    </div>
                    <div className="bg-slate-950 text-white py-1 px-2 rounded-md font-mono text-xs font-black">
                      {String(countdown.mins).padStart(2, '0')}<span className="text-[7px] text-slate-400 block font-normal">Phút</span>
                    </div>
                    <div className="bg-slate-950 text-white py-1 px-2 rounded-md font-mono text-xs font-black">
                      {String(countdown.secs).padStart(2, '0')}<span className="text-[7px] text-slate-400 block font-normal">Giây</span>
                    </div>
                  </div>
                  <p className="text-[9.5px] text-slate-400 mt-1.5">Số lượng còn lại: <strong className="text-red-500">14 cuốn cuối cùng</strong></p>
                </div>

                {/* Instant scroll triggers */}
                <button
                  type="button"
                  onClick={() => {
                    const el = document.getElementById("mobile-checkout-anchor");
                    el?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="w-full py-3 px-4 bg-gradient-to-r from-red-600 to-orange-500 text-white font-extrabold text-xs rounded-lg uppercase tracking-wide shadow-md hover:scale-[1.01] active:scale-95 transition btn-urgent-buy cursor-pointer text-center"
                >
                  XÁC NHẬN MUA NGAY GIẢM 50%
                </button>

                <div className="flex justify-between items-center text-[9.5px] text-slate-450 text-slate-400 mt-3 px-1 font-medium">
                  <span>✓ Miễn phí ship COD</span>
                  <span>✓ Kiểm hàng nhận sách</span>
                </div>
              </div>

              {/* PROBLEM BLOCK */}
              <div className="py-6 px-3 bg-slate-50 border-b border-slate-100">
                <span className="text-[8.5px] font-bold text-red-500 bg-red-100 px-2 py-0.5 rounded-full uppercase">SỰ THẬT ĐÁNG LO</span>
                <h3 className="text-xs font-black text-slate-900 mt-1.5 mb-4 uppercase leading-snug">
                  {config.problemTitle}
                </h3>

                <div className="space-y-2">
                  {config.problems.map((prob, idx) => (
                    <div key={idx} className="flex items-start gap-2 bg-white p-2.5 rounded-lg border border-red-100/40">
                      <span className="text-red-500 font-extrabold text-xs mt-0.5 flex-shrink-0 bg-red-50 w-4 h-4 rounded-full flex items-center justify-center">✗</span>
                      <p className="text-[10.5px] text-slate-600 leading-relaxed font-medium">{prob}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* CORE SOLUTIONS */}
              <div className="py-6 px-3 border-b border-slate-100">
                <span className="text-[8.5px] font-bold text-emerald-600 bg-emerald-100/80 px-2 py-0.5 rounded-full uppercase">ƯU THẾ VƯỢT TRỘI</span>
                <h3 className="text-xs font-black text-slate-900 mt-1.5 mb-4 uppercase leading-snug">
                  {config.solutionTitle}
                </h3>

                <div className="space-y-3.5">
                  {config.solutions.map((sol, idx) => (
                    <div key={idx} className="bg-gradient-to-br from-indigo-50/10 to-emerald-50/20 border border-emerald-100/50 p-3 rounded-xl">
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className="w-4 h-4 rounded-full bg-emerald-500 text-slate-900 flex items-center justify-center font-mono font-black text-[10px]">
                          {idx+1}
                        </span>
                        <h4 className="text-[11px] font-black uppercase text-teal-850 tracking-tight">{sol.title}</h4>
                      </div>
                      <p className="text-[10.5px] text-slate-500 leading-relaxed pl-5">{sol.desc}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* BENEFITS BLACK PANEL */}
              <div className="py-6 px-3 bg-slate-900 text-white border-b border-indigo-950 relative overflow-hidden">
                <div className="absolute -right-6 -bottom-6 w-16 h-16 bg-orange-500/5 rounded-full blur-xl"></div>
                <span className="text-[8.5px] font-bold text-orange-400 border border-orange-400/30 px-2 py-0.5 rounded-full uppercase">HÀNH TRANG THAY ĐỔI TRÍ TUỆ</span>
                <h3 className="text-xs font-black mt-2 mb-4 uppercase leading-snug">
                  {config.benefitsTitle}
                </h3>

                <div className="space-y-2.5">
                  {config.benefits.map((benefit, idx) => (
                    <div key={idx} className="flex items-start gap-2 bg-slate-800/50 p-2.5 rounded-lg border border-slate-700/20">
                      <span className="text-[9.5px] bg-emerald-500 text-slate-950 rounded-full w-4 h-4 flex items-center justify-center flex-shrink-0 mt-0.5 font-bold">✓</span>
                      <p className="text-[10.5px] text-zinc-350 leading-relaxed font-semibold">{benefit}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* CLIENT FEEDBACK MOCKS */}
              <div className="py-6 px-3 bg-slate-50 border-b border-slate-100">
                <span className="text-[8.5px] font-bold text-orange-500 bg-orange-100 px-2 py-0.5 rounded-full uppercase">ĐỘC GIẢ PHẢN HỒI</span>
                <h3 className="text-xs font-black text-slate-900 mt-1.5 mb-4 uppercase leading-snug">
                  {config.testimonialsTitle}
                </h3>

                <div className="space-y-3">
                  {/* Render custom input reviews made in real-time */}
                  {customReviews.map(rev => (
                    <div key={rev.id} className="bg-white p-3 rounded-lg border border-slate-100/80 shadow-xs">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-1.5">
                          <div className="w-6.5 h-6.5 rounded-full bg-orange-500 text-white font-black flex items-center justify-center text-[10px] uppercase">
                            {rev.author.charAt(0)}
                          </div>
                          <div>
                            <div className="flex items-center gap-1 text-[10.5px] font-bold text-slate-800">
                              {rev.author}
                              <span className="bg-emerald-50 text-emerald-600 text-[7px] px-1 py-0.1 rounded font-black">✓ Độc giả</span>
                            </div>
                            <span className="text-amber-500 text-[8px]">★ ★ ★ ★ ★</span>
                          </div>
                        </div>
                        <span className="text-[8.5px] text-slate-400">{rev.date}</span>
                      </div>
                      <p className="text-[10px] text-slate-600 pl-0.5">{rev.content}</p>
                    </div>
                  ))}

                  {/* Standard predefined testimonials list */}
                  {config.testimonials.map(test => (
                    <div key={test.id} className="bg-white p-3 rounded-lg border border-slate-100/80 shadow-xs">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-1.5">
                          <img 
                            src={test.avatar} 
                            alt={test.author} 
                            className="w-6.5 h-6.5 rounded-full object-cover ring-2 ring-slate-100"
                            onError={(e) => { e.currentTarget.src = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150"; }}
                          />
                          <div>
                            <div className="flex items-center gap-1 text-[10.5px] font-bold text-slate-800">
                              {test.author}
                              {test.verified && <span className="bg-emerald-50 text-emerald-600 text-[7px] px-1 py-0.1 rounded font-black">✓ Đã đặt mua</span>}
                            </div>
                            <span className="text-amber-500 text-[8px]">
                              {Array(test.rating).fill('★').join(' ')}
                            </span>
                          </div>
                        </div>
                        <span className="text-[8.5px] text-slate-400">{test.date}</span>
                      </div>
                      <p className="text-[10px] text-slate-600 pl-0.5 leading-relaxed font-medium">{test.content}</p>

                      {test.replies && test.replies.map((reply, rid) => (
                        <div key={rid} className="bg-slate-50 border-l border-orange-500 p-1.5 rounded mt-1.5 ml-1.5 leading-relaxed">
                          <span className="text-[8.5px] font-bold text-orange-500">{reply.author} <span className="text-[7.5px] bg-orange-100 text-orange-800 px-1 py-0.1 rounded font-normal">Admin</span></span>
                          <p className="text-[9px] text-slate-500">{reply.content}</p>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>

                {/* Submitting test review instantly inside phone mockup */}
                <div className="bg-white p-3 rounded-lg border border-dashed border-slate-200 mt-3.5 space-y-2">
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-wider block">GỬI BÌNH LUẬN TRỰC TIẾP TRÊN MOBILE FEED:</span>
                  <div className="flex items-center gap-1">
                    <span className="text-[9.5px] text-slate-400">Đánh giá sao:</span>
                    <div className="flex text-amber-500 text-[10px] gap-0.5 cursor-pointer">
                      {[1,2,3,4,5].map(st => (
                        <button key={st} onClick={() => setUserStars(st)} type="button">
                          {userStars >= st ? "★" : "☆"}
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <input 
                    type="text" 
                    placeholder="Họ tên độc giả..." 
                    value={userCommentName}
                    onChange={e => setUserCommentName(e.target.value)}
                    className="w-full text-[9.5px] p-2 bg-slate-50 border border-slate-200 rounded focus:outline-none"
                  />
                  <textarea 
                    placeholder="Cảm nhận đọc sách..." 
                    rows={1}
                    value={userCommentText}
                    onChange={e => setUserCommentText(e.target.value)}
                    className="w-full text-[9.5px] p-2 bg-slate-50 border border-slate-200 rounded focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleAddPreviewReview}
                    className="w-full py-1 bg-slate-900 text-white font-bold text-[9px] rounded uppercase hover:bg-slate-800 transition"
                  >
                    ĐĂNG ĐÚNG LUỒNG
                  </button>
                </div>
              </div>

              {/* GAMIFICATION - LUCKY SPIN WHEEL */}
              <div className="py-6 px-3 bg-gradient-to-tr from-amber-50 to-orange-50 border-b border-amber-100 text-center">
                <span className="inline-flex items-center gap-0.5 bg-orange-100 text-orange-700 text-[8.5px] font-black px-2 py-0.5 rounded-full uppercase mb-1">
                  <Sparkles className="w-2.5 h-2.5 text-orange-500 animate-spin" /> Vòng quay may mắn
                </span>
                <h4 className="text-[11px] font-black text-slate-800 uppercase">THỬ SỰ MAY MẮN NHẬN QUÀ</h4>
                
                {/* Visual wheel element with styling */}
                <div className="max-w-[130px] mx-auto relative my-3.5">
                  <div 
                    style={{ transform: `rotate(${wheelRotation}deg)` }}
                    className="w-28 h-28 rounded-full border-4 border-amber-400 bg-gradient-to-br from-red-500 via-orange-400 to-amber-300 mx-auto transition-transform duration-[3000ms] ease-out shadow flex items-center justify-center text-white font-bold text-[9px] relative overflow-hidden"
                  >
                    <div className="absolute w-full h-0.5 bg-white/20 top-1/2 left-0"></div>
                    <div className="absolute w-full h-0.5 bg-white/20 top-0 left-1/2 transform -translate-x-1/2 rotate-90"></div>
                    <span className="z-10 bg-slate-950 font-black px-1.5 py-1 text-[7px] uppercase tracking-wide rounded-full text-amber-400 whitespace-nowrap">QUAY</span>
                  </div>
                  {/* Needle indicator pointer */}
                  <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1 w-2.5 h-3 bg-red-650 bg-red-605 bg-red-600 rounded"></div>
                </div>

                <button
                  type="button"
                  disabled={isSpinning || hasSpun}
                  onClick={handleSpinWheel}
                  className="py-1.5 px-4 bg-orange-500 text-white font-black text-[9px] rounded-full uppercase tracking-wider shadow-sm hover:bg-orange-600 transition disabled:opacity-50 cursor-pointer"
                >
                  {isSpinning ? "Đang quay giải..." : hasSpun ? "Bạn đã quay mã" : "Quay ngay"}
                </button>
                {spinResult && (
                  <p className="text-[9.5px] text-emerald-600 font-extrabold mt-2 italic px-1 leading-tight">{spinResult}</p>
                )}
              </div>

              {/* CORE ORDER CHECKOUT FORM */}
              <div id="mobile-checkout-anchor" className="py-7 px-3 bg-white scroll-mt-20">
                <div className="text-center mb-4">
                  <span className="text-[8.5px] font-bold text-red-500 bg-red-100 px-2.5 py-0.5 rounded-full uppercase tracking-wider">ĐĂNG KÝ HỌC & ĐỌC</span>
                  <h3 className="text-xs font-black text-slate-900 mt-2 uppercase leading-snug">
                    {config.packagesTitle}
                  </h3>
                  <p className="text-[9.5px] text-slate-400 mt-1 leading-relaxed">Thông tin bảo mật. Nhận hàng COD kiểm tra 100% rồi thanh toán.</p>
                </div>

                <form onSubmit={handleCheckoutSubmit} className="space-y-4">
                  
                  {/* Selectors inside mobile container */}
                  <div className="space-y-2.5">
                    <span className="text-[10px] font-black text-slate-650 block text-slate-500 uppercase">1. LỰA CHỌN PHIÊN BẢN CỦA BẠN:</span>
                    
                    {config.packages.map(pkg => {
                      const isActive = selectedPackageId === pkg.id;
                      return (
                        <div
                          key={pkg.id}
                          onClick={() => setSelectedPackageId(pkg.id)}
                          className={`border p-2.5 rounded-xl cursor-pointer transition relative flex items-start gap-2.5 ${
                            isActive ? "border-orange-500 bg-orange-500/[0.03]" : "border-slate-200 bg-white"
                          }`}
                        >
                          <input 
                            type="radio"
                            name="mobile_pkg_radio"
                            checked={isActive}
                            onChange={() => setSelectedPackageId(pkg.id)}
                            className="text-orange-500 focus:ring-orange-500 mt-1 w-3.5 h-3.5"
                          />
                          <div className="flex-1 pr-4">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="text-[10.5px] font-extrabold text-slate-900 uppercase">{pkg.name}</span>
                              {pkg.badge && (
                                <span className="bg-red-550 bg-red-500 text-white text-[7px] font-black px-1.5 py-0.2 rounded uppercase">
                                  {pkg.badge}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-xs font-black text-red-600">{formatMoney(pkg.salePrice)}</span>
                              <span className="text-[9px] font-semibold text-slate-400 line-through">{formatMoney(pkg.originalPrice)}</span>
                            </div>
                            <p className="text-[9px] text-slate-450 text-slate-400 mt-0.5 leading-snug">{pkg.description}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Customer details fields with mock placeholders */}
                  <div className="bg-slate-50 p-3 rounded-xl space-y-2.5 border border-slate-100">
                    <span className="text-[10px] font-black text-slate-500 block uppercase">2. THÔNG TIN KHÁCH HÀNG:</span>
                    
                    <input
                      type="text"
                      required
                      placeholder="Họ tên của bạn..."
                      value={clientName}
                      onChange={e => setClientName(e.target.value)}
                      className="w-full text-[10.5px] p-2 bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-orange-500 font-medium"
                    />

                    <div>
                      <input
                        type="tel"
                        required
                        placeholder="Số điện thoại di động Việt Nam..."
                        value={clientPhone}
                        onChange={e => setClientPhone(e.target.value)}
                        className={`w-full text-[10.5px] p-2 bg-white border rounded-md focus:outline-none focus:ring-1 focus:ring-orange-500 font-medium ${
                          phoneError ? "border-red-500 bg-red-50" : "border-slate-200"
                        }`}
                      />
                      {phoneError && (
                        <p className="text-[9px] text-red-500 font-medium mt-1">SĐT sai định dạng (Ví dụ: 0987654321, có 10 chữ số).</p>
                      )}
                    </div>

                    <textarea
                      required
                      placeholder="Ghi rõ Số nhà, Tên đường, Quận, Tỉnh Thành để bưu tá giao chính xác..."
                      rows={2}
                      value={clientAddress}
                      onChange={e => setClientAddress(e.target.value)}
                      className="w-full text-[10.5px] p-2 bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-orange-500 font-medium resize-none"
                    />

                    <input
                      type="text"
                      placeholder="Nhập ghi chú giao nhận khi ship..."
                      value={clientNote}
                      onChange={e => setClientNote(e.target.value)}
                      className="w-full text-[10.5px] p-2 bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-orange-500"
                    />
                  </div>

                  {/* Pricing dynamic calculation summary */}
                  <div className="bg-slate-900 text-white rounded-lg p-2.5 flex justify-between items-center px-3.5">
                    <span className="text-[10px] font-bold text-slate-350">Tổng tiền COD thu hộ:</span>
                    <span className="text-sm font-black text-orange-400">
                      {formatMoney(
                        config.packages.find(p => p.id === selectedPackageId)?.salePrice || 0
                      )}
                    </span>
                  </div>

                  {/* Submission checkout trigger with thumb responsive sizing in mobile */}
                  <button
                    type="submit"
                    className="w-full py-3 px-4 bg-gradient-to-r from-red-650 from-red-600 to-orange-500 hover:from-red-700 text-white font-extrabold text-xs sm:text-sm rounded-xl uppercase tracking-wider shadow-md transition duration-200 text-center cursor-pointer flex justify-center items-center gap-1.5"
                  >
                    XÁC NHẬN MUA NGAY SÁCH
                  </button>
                  
                  <div className="text-[9.5px] text-slate-400 text-center font-medium">
                    🛡️ Điền thông tin chính xác để nhận quyền lợi ưu đãi giảm giá tốt nhất!
                  </div>

                </form>
              </div>

              {/* FOOTBLOCK INSIDE PHONE PREVIEW */}
              <footer className="bg-slate-900 border-t border-slate-800 text-slate-500 pt-6 pb-20 px-3 text-center text-[9px] leading-relaxed">
                <div className="max-w-xs mx-auto space-y-2">
                  <p className="text-zinc-300 font-black uppercase text-[9.5px]">{config.companyName}</p>
                  <p>{config.companyAddress}</p>
                  <p>{config.companyContact}</p>
                  <div className="border-t border-slate-800 pt-2 text-[8px] text-slate-550">
                    <p>© 2026 Bản quyền thuộc về CLB SÁCH TINH HOA vN</p>
                  </div>
                </div>
              </footer>

            </div>

            {/* LIVE PREVIEW FLOATING TRIGGER SUCCESS STATE EMBED / DIAL */}
            {successOrder && (
              <div className="absolute inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3.5">
                <div className="bg-white rounded-2xl w-full max-w-xs overflow-hidden shadow-2xl scale-100 transition-all duration-300">
                  <div className="bg-gradient-to-br from-emerald-500 to-teal-500 p-4 text-center text-white">
                    <div className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-1.5">
                      <Check className="w-5 h-5 text-white" />
                    </div>
                    <h4 className="text-xs font-black uppercase">ĐẶT HÀNG THÀNH CÔNG!</h4>
                    <p className="text-[9.5px] text-emerald-100 mt-0.5">Chúng tôi đã tiếp nhận đơn của bạn.</p>
                  </div>
                  
                  <div className="p-4 space-y-3">
                    <div className="text-[10px] text-slate-500 space-y-1 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <p><strong className="text-slate-700">Khách:</strong> {successOrder.customerName}</p>
                      <p><strong class="text-slate-700 font-semibold">SĐT:</strong> {successOrder.customerPhone}</p>
                      <p className="truncate"><strong class="text-slate-700 font-semibold font-semibold">Ngoại gói:</strong> {successOrder.selectedPackageName}</p>
                      <p className="text-red-650 text-red-600 font-bold mt-1 text-[11px] flex justify-between items-center border-t border-slate-200/60 pt-1">
                        <span>Giá COD:</span> 
                        <span>{formatMoney(successOrder.totalPrice)}</span>
                      </p>
                    </div>

                    <div className="bg-emerald-50 text-emerald-800 text-[9px] p-2 rounded leading-relaxed border border-emerald-100">
                      🚚 <strong>Giao hàng:</strong> Điện thoại xác nhận trong 15 phút. Sách sẽ đến tay bạn sau 2-4 ngày làm việc.
                    </div>

                    <button
                      type="button"
                      onClick={handleCloseSuccessPopup}
                      className="w-full py-2 bg-slate-900 text-white font-extrabold text-[10px] rounded-lg uppercase tracking-wide hover:bg-slate-800 transition shadow"
                    >
                      Xong & Đóng
                    </button>
                    
                    {webhookStatus === "success" && (
                      <p className="text-[8.5px] text-emerald-600 bg-emerald-50 p-1.5 rounded text-center font-bold">✓ Gửi lên Google Sheet!</p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* PHYSICAL HOME BOTTOM INDICATOR BAR */}
            <div className="absolute bottom-1 right-1/2 transform translate-x-1/2 w-32 h-1 bg-slate-700 rounded-full z-30"></div>

          </div>

          {/* PHYSICAL ADVERTISING FLOATER */}
          <div className="hidden xl:flex flex-col gap-4 max-w-[200px] ml-6 text-slate-400 select-none">
            <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-2xl text-center space-y-2">
              <Smartphone className="w-8 h-8 text-orange-400 mx-auto" />
              <h5 className="text-[11px] font-black text-white uppercase">Tối Ưu Mobile Frame</h5>
              <p className="text-[10.5px] leading-relaxed text-zinc-400">Thiết kế được kiểm soát hiển thị theo kích cỡ chuẩn iPhone để người mua chỉ cần lướt ngón tay cái là đặt mua được ngay!</p>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-2xl text-center space-y-2">
              <Gift className="w-8 h-8 text-emerald-400 mx-auto" />
              <h5 className="text-[11px] font-black text-white uppercase">Hiệu ứng kích thích</h5>
              <p className="text-[10.5px] leading-relaxed text-zinc-400">Tính năng vòng quay may mắn, countdown timer và các nút bấm lắc lư tạo không khí gấp gáp, tăng 30% doanh số!</p>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
